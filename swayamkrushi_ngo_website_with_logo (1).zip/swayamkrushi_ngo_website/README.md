# Swayamkrushi NGO website starter

## Files
- `public/index.html`, `public/styles.css`, `public/script.js`: responsive website front end.
- `server.js`: optional Node/Express Razorpay order + signature verification starter.
- `.env.example`: environment variable names only.

## Before publishing
1. Replace the sample stock photographs with NGO-owned, consented photographs.
2. Confirm the public contact email and replace `REPLACE_WITH_PUBLIC_NGO_EMAIL` in `public/script.js`.
3. Confirm address, phone, programme descriptions, old-age-home facilities, registration details and all legal claims with the NGO.
4. Do not publish unverified beneficiary counts, 80G claims or donation account information.
5. Add the official NGO logo when the organization supplies the logo file. The current mark is a temporary text/vector wordmark.
6. Configure the contact form with a trusted form service or your own protected backend. The current form opens the visitor's email app.
7. Configure Razorpay KYC under the NGO's own account. Keep the Key Secret only in server environment variables.
8. Add HTTPS, spam protection, rate limiting, a privacy notice and a data-retention policy before collecting personal information.

## Run locally
1. Install Node.js.
2. Run `npm install`.
3. Copy `.env.example` to `.env` and add the NGO's Razorpay test credentials only after account approval.
4. Run `npm start`.
5. Open `http://localhost:3000`.

The current donation button is intentionally a non-live demo. The backend creates and verifies orders, but the checkout UI, webhook signature verification, database storage, receipts and admin authentication still need to be completed and tested before accepting real donations. Never use the NGO email password as a website admin password.
