// Secure Razorpay backend starter. Never put Razorpay secret keys in browser code.
require('dotenv').config();
const express = require('express');
const Razorpay = require('razorpay');
const crypto = require('crypto');
const app = express();
app.use(express.json());
app.use(express.static('public'));

const required = ['RAZORPAY_KEY_ID','RAZORPAY_KEY_SECRET'];
if (required.some(k => !process.env[k])) {
  console.warn('Razorpay keys are not configured. Donation checkout is disabled.');
}
const razorpay = process.env.RAZORPAY_KEY_ID && process.env.RAZORPAY_KEY_SECRET
  ? new Razorpay({key_id:process.env.RAZORPAY_KEY_ID,key_secret:process.env.RAZORPAY_KEY_SECRET})
  : null;

app.post('/api/create-order', async (req,res) => {
  try {
    if (!razorpay) return res.status(503).json({error:'Donations are not activated yet.'});
    const amount = Number(req.body.amount);
    if (!Number.isInteger(amount) || amount < 1 || amount > 1000000) return res.status(400).json({error:'Invalid amount'});
    const order = await razorpay.orders.create({amount:amount*100,currency:'INR',receipt:'sruds_'+Date.now()});
    res.json({orderId:order.id, amount:order.amount, currency:order.currency, keyId:process.env.RAZORPAY_KEY_ID});
  } catch(e) { console.error(e); res.status(500).json({error:'Unable to create payment order'}); }
});

app.post('/api/verify-payment', (req,res) => {
  const {razorpay_order_id,razorpay_payment_id,razorpay_signature}=req.body;
  if (!process.env.RAZORPAY_KEY_SECRET) return res.status(503).json({verified:false});
  const expected=crypto.createHmac('sha256',process.env.RAZORPAY_KEY_SECRET)
    .update(razorpay_order_id+'|'+razorpay_payment_id).digest('hex');
  const a=Buffer.from(expected); const b=Buffer.from(razorpay_signature||'');
  const valid=a.length===b.length && crypto.timingSafeEqual(a,b);
  if(!valid) return res.status(400).json({verified:false});
  // TODO: persist donation record securely and send acknowledgement only after verification.
  res.json({verified:true});
});

const port=process.env.PORT||3000;
app.listen(port,()=>console.log('Swayamkrushi server running on '+port));
